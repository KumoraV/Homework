Done by Christopher Fallas Aguero for HW3 CSIT313
Code written and tested in Visual Studio Code.

CSIT313HW3FallasChristopher.docx contains answers for part A and eassy for part B.

compareJava.java and comparePython.py is the source code for part A1.
This compares the case-sensitivity, keywords as reserved words, and type of variables.

scopeC.c, scopeC++.cc, and scopeJava.java is the source code for part B
This determines the scope of a variable declares in a for statement.

To run these files, the compiled verisons are available in the folder "Compiled Code".
Otherwise, compile the source code and use the appropriate interpeter to run it.
Tested in Visual Studio Code and Bash.