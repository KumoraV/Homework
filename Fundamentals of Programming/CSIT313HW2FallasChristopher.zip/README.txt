Code made by Christopher Fallas Aguero

countingLoopMatrix.c does matrix multiplication using for loops.
logicalMatrix.c does matrix multiplication using while loops.
Change permissions on compiled code to run it.
Otherwise, compile source code with C compiler.

Matrices are hard coded.
To change the values, you have to edit the source code.
The output will show the original two matricies and 
the result from matrix multiplication.
