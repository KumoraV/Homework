// C++ program that tests the scope of a variable inside a for loop
#include <iostream>

int main()
{
    for (int i = 0; i < 1; i++)
    {
        int inside = 5;
        std::cout << "Printing value inside the for loop: " << inside;
    }
    // Making the bottom comment into code will give an error.
    // std::cout << "Printing value outside the for loop:" << inside;
}